library(haven)
library(dplyr)
library(tidyr)
library(readxl)
library(datetime)
library(lubridate)
library(stringr)
library(data.table)
library(openxlsx)
library(clipr)
library(survey)
library(ggplot2)
library(ggpubr)

# =========================SCREENING STAGE=========================


# Reading dataset ----
#case-level dataset (full sample)
setwd("O:/AFHS-DATA/Analysis/Shiyu/dissertation/JSSAM code data submission")
dCase<- read_sas("JSSAMsubmission_screenStage_caselevel.sas7bdat")
dim(dCase)


#screening dataset (screening respondents)
setwd("O:/AFHS-DATA/Analysis/Shiyu/dissertation/JSSAM code data submission")
dScreen<- read_sas("JSSAMsubmission_screenStage_screen.sas7bdat")
dim(dScreen)



#Response indicator----
table(dCase$ScreenerDone, exclude= F)

dCase<- dCase%>%
  mutate(screenYes= case_when(
    ScreenerDone== 1~ 1,
    TRUE~ 0
  ))

table(dCase$ScreenerDone, dCase$screenYes, exclude= F)

# Adaptive design experiment ----

## Response rate ----
table(dCase$ESRIstratum, dCase$Adaptive_Exp, exclude= F)
table(dCase$screenYes, dCase$ESRIstratum, dCase$Adaptive_Exp, exclude= F)


tb<- dCase%>%
  filter(ESRIstratum== "Hispanic")%>%
  select(screenYes, Adaptive_Exp)%>%
  table(exclude= F)
chisq.test(tb)

tb<- dCase%>%
  filter(ESRIstratum== "Rustic Outposts")%>%
  select(screenYes, Adaptive_Exp)%>%
  table(exclude= F)
chisq.test(tb)




# Respondent composition (screener) ----

## Demographic processing ---

### 1. gender----
table(dScreen$RespGender, exclude= F)
dScreen<- dScreen%>%
  dplyr::mutate(
    male_screen= case_when(
      RespGender==1~ 1,
      RespGender==5~ 0)
    )
table(dScreen$RespGender, dScreen$male_screen, exclude= F)

### 2. age----
summary(dScreen$RespBirthYear)
sum(dScreen$RespBirthYear>2010, na.rm= T)


dScreen<- dScreen%>%
  dplyr::mutate(
    age_screen= case_when(
      RespBirthYear>2010~ NA_real_,
      RespBirthYear<1900~ NA_real_,
      TRUE~ 2021- RespBirthYear
    ),
    agecat_screen= case_when(
      age_screen< 25~ "<25",
      age_screen>= 25 & age_screen< 35~ "25-34",
      age_screen>= 35 & age_screen< 50~ "35-49",
      age_screen>= 50~ "50+"
    )
  )
summary(dScreen$age_screen)
table(dScreen$agecat_screen, exclude= F)


### 3. race and ethnicity----
# race of screener respondent
table(dScreen$RespRace_1, exclude= F)
table(dScreen$RespRace_2, exclude= F)
table(dScreen$RespRace_3, exclude= F)
table(dScreen$RespRace_4, exclude= F)
table(dScreen$RespRace_5, exclude= F)

dScreen$raceCount_screen<- dScreen%>%
  dplyr::select(RespRace_1, RespRace_2,
                RespRace_3, RespRace_4,
                RespRace_5)%>%
  apply(., 1, function(x) sum(!is.na(x)))


table(dScreen$RespEthnicity, exclude= F)
dScreen<- dScreen%>%
  dplyr::mutate(raceEthnicity_screen= dplyr::case_when(
    RespEthnicity== 1~ "Hispanic",
    (RespEthnicity== 5| is.na(RespEthnicity)) & raceCount_screen==1 & RespRace_1== 5~ "Non-H White",
    (RespEthnicity== 5| is.na(RespEthnicity)) & raceCount_screen==1 & RespRace_1== 4~ "Non-H Black",
    (RespEthnicity== 5| is.na(RespEthnicity)) & raceCount_screen==1 & RespRace_1== 2~ "Non-H Other",
    (RespEthnicity== 5| is.na(RespEthnicity)) & raceCount_screen==1 & RespRace_1== 1~ "Non-H Other",
    (RespEthnicity== 5| is.na(RespEthnicity)) & raceCount_screen==1 & RespRace_1== 3~ "Non-H Other",
    (RespEthnicity== 5| is.na(RespEthnicity)) & raceCount_screen>1 ~ "Non-H Other" #"Non-H Multi"
  ))

table(dScreen$raceEthnicity_screen, exclude = F)



### 4. household size ----
summary(dScreen$NumOfAdults)
dScreen<- dScreen%>%
  dplyr::mutate(NumOfAdultsCat= case_when(
    NumOfAdults== 1~ "1",
    NumOfAdults== 2~ "2",
    NumOfAdults== 3~ "3",
    NumOfAdults>= 4~ "4+"
  ))
table(dScreen$NumOfAdults, dScreen$NumOfAdultsCat, exclude= F)


### 5. Household eligibility ----
table(dScreen$NumOfEligible, exclude= F)
dScreen<- dScreen%>%
  dplyr::mutate(yesElig= case_when(
    NumOfEligible>0~ 1,
    TRUE~ 0
  ))
table(dScreen$NumOfEligible, dScreen$yesElig, exclude= F)



## Respondents of Hispanic group ----
table(dScreen$ESRIstratum, exclude= F)
dScreen_hisp<- dScreen%>%
  filter(ESRIstratum== "Hispanic")


tb<- table(dScreen_hisp$Adaptive_Exp,
           dScreen_hisp$male_screen)
tb
tb%>% write_clip()
chisq.test(tb)

tb<- table(dScreen_hisp$Adaptive_Exp,
           dScreen_hisp$agecat_screen)
tb
tb%>% write_clip()
chisq.test(tb)

tb<- table(dScreen_hisp$Adaptive_Exp,
           dScreen_hisp$raceEthnicity_screen)
tb
tb%>% write_clip()
chisq.test(tb)

tb<- table(dScreen_hisp$Adaptive_Exp,
           dScreen_hisp$NumOfAdultsCat)
tb
tb%>% write_clip()
chisq.test(tb)

tb<- table(dScreen_hisp$Adaptive_Exp,
           dScreen_hisp$yesElig)
tb
tb%>% write_clip()
chisq.test(tb)


## Respondents of Rustic group ----
table(dScreen$ESRIstratum, exclude= F)
dScreen_rust<- dScreen%>%
  filter(ESRIstratum== "Rustic Outposts")


tb<- table(dScreen_rust$Adaptive_Exp,
           dScreen_rust$male_screen)
tb
tb%>% write_clip()
chisq.test(tb)

tb<- table(dScreen_rust$Adaptive_Exp,
           dScreen_rust$agecat_screen)
tb
tb%>% write_clip()
chisq.test(tb)

tb<- table(dScreen_rust$Adaptive_Exp,
           dScreen_rust$raceEthnicity_screen)
tb
tb%>% write_clip()
chisq.test(tb)

tb<- table(dScreen_rust$Adaptive_Exp,
           dScreen_rust$NumOfAdultsCat)
tb
tb%>% write_clip()
chisq.test(tb)

tb<- table(dScreen_rust$Adaptive_Exp,
           dScreen_rust$yesElig)
tb
tb%>% write_clip()
chisq.test(tb)



# ========================= MAIN STAGE =========================

# This script omits the analysis about the email and phone numbers provided by the screening informants. 





# REPLICATE 2 ==============================

# Reading dataset ----
#case-level dataset (eligible for main survey)
setwd("O:/AFHS-DATA/Analysis/Shiyu/dissertation/JSSAM code data submission")
dCase_main<- read_sas("JSSAMsubmission_mainStage_R2_eligibleMain.sas7bdat")

#main dataset
setwd("O:/AFHS-DATA/Analysis/Shiyu/dissertation/JSSAM code data submission")
dMainFw<- read_sas("JSSAMsubmission_mainStage_R2_male.sas7bdat")
dMainMw<- read_sas("JSSAMsubmission_mainStage_R2_female.sas7bdat")

## cross walk between variable name and variable meaning
setwd("O:/AFHS-DATA/Analysis/Shiyu/dissertation/JSSAM code data submission")
varDict<- read_excel("helper_varName_text.xlsx") 


# Response rate ----
# Who was selected? Informant or "another member"?
table(dCase_main$ExportBlock_InfIsSelected, exclude= F)

# response rate
table(dCase_main$ExportBlock_InfIsSelected, dCase_main$mainResp, exclude= F)
  #mainResp indicates the cases in the final response datasets


# Odds ratios (informant/noninformant) by replicate ----

# manual - testing joint independence (XY _||_ Z)
# -- the joint distribution of XY is independent of Z
# -- X=informant/noninformant, Y=response/nonresponse, Z=R1/R2
table<- data.frame("R1"= c(642, 122, 356, 394), 
                   "R2"= c(912, 218, 436, 593))
chisq.test(table)

# Odds ratio
# R1 - informants
odds1i<- (642/764)/(1-642/764) 
# R1 - noninformants
odds1n<- (356/750)/(1-356/750) 
# OR
odds1i/odds1n
log(odds1i/odds1n)

# R2 - informants
odds2i<- (912/1130)/(1-912/1130) 
# R2 - noninformants
odds2n<- (436/1029)/(1-436/1029) 
# OR
odds2i/odds2n
log(odds2i/odds2n)

#d= log(OR1)- log(OR2)
d<- log(odds1i/odds1n)- log(odds2i/odds2n)

#Var(d)= var(log(OR1))+ var(log(OR2))
v<- 1/642+ 1/122+ 1/356+ 1/394+ 1/912+ 1/218+ 1/436+ 1/593

#SE(d)= sqrt(Var(d))
se<- sqrt(v)

#t= d/SE(d)
d/se




# Main survey estimates ----
## Male ----
dMainMw$SecMaleA_EVRCOHAB_original<- dMainMw$SecMaleA_EVRCOHAB #fix variable coding
dMainMw<- dMainMw%>% mutate(
  EVRCOHAB_sz= case_when(
    (SecMaleA_MARSTAT== 2 | SecMaleA_EVCOHAB1== 1 | SecMaleA_EVCOHAB2 ==1) ~ 1,
    TRUE~ 0
  ),
  SecMaleA_EVRCOHAB= EVRCOHAB_sz
)



varM<- c("SecMaleA_EVRCOHAB",
         "SecMaleA_ONOWN",
         "SecMaleA_GOSCHOL",
         "SecMaleA_PARMARR",
         "SecMaleB_EVEROPER",
         "SecMaleA_WOMRASDU",
         "SecMaleA_MANRASDU")



dMainMw[varM]<- data.frame((dMainMw[varM]==1)*1) #recoding variables



options(survey.lonely.psu="adjust") #http://r-survey.r-forge.r-project.org/survey/exmample-lonely.html
design<- svrepdesign(ids= ~0, strata= ~pseudo_strata, 
                     data= dMainMw, 
                     weight= ~PS_Wgt_Male1_trimmed,
                     repweights= "PS_Wgt_Male1_trimmed_BS_[1-9]", 
                     type= "bootstrap")


estimates<- data.frame(matrix(ncol = 5, nrow = 0))
for (v in varM){
  est<- svymean(~eval(parse(text= v)), design, na.rm= T)
  ci<- svyciprop(~ eval(parse(text= v)), design, na.rm= T, method= "beta")
  
  row<- c(v, mean(est), SE(est), attr(ci, "ci")[1], attr(ci, "ci")[2])
  
  estimates<- rbind(estimates, row)
}

colnames(estimates)<- c("variable", "mean", "SE", "ciLow", "ciHigh")
estimates$replicate<- "R2"
estimates

estimates_M_R2<- estimates #assigning to a different name



## Female----
varF<- c("SecFemC_EVRCOHAB",
         "SecFemA_ONOWN",
         "SecFemA_GOSCHOL",
         "SecFemB_PREGNOWQ",
         "SecFemA_PARMARR",
         "SecFemC_EVERSEX",
         "SecFemA_WOMRASDU",
         "SecFemA_MANRASDU")


dMainFw[varF]<- data.frame((dMainFw[varF]==1)*1) #recoding variables


options(survey.lonely.psu="adjust") #http://r-survey.r-forge.r-project.org/survey/exmample-lonely.html
design<- svrepdesign(ids= ~0, strata= ~pseudo_strata, 
                     data= dMainFw, 
                     weight= ~PS_Wgt_Female1_trimmed,
                     repweights= "PS_Wgt_Female1_trimmed_BS_[1-9]", 
                     type= "bootstrap")

estimates<- data.frame(matrix(ncol = 5, nrow = 0))
for (v in varF){
  est<- svymean(~eval(parse(text= v)), design, na.rm= T)
  ci<- svyciprop(~ eval(parse(text= v)), design, na.rm= T, method= "beta")
  
  row<- c(v, mean(est), SE(est), attr(ci, "ci")[1], attr(ci, "ci")[2])
  
  estimates<- rbind(estimates, row)
}

colnames(estimates)<- c("variable", "mean", "SE", "ciLow", "ciHigh")
estimates$replicate<- "R2"
estimates

estimates_F_R2<- estimates

## binding Male and Female estimates ----
estimates_R2<- rbind(estimates_M_R2, estimates_F_R2)






# REPLICATE 1 ==============================


# Reading dataset ----
#case-level dataset (full sample)
setwd("O:/AFHS-DATA/Analysis/Shiyu/dissertation/JSSAM code data submission")
dCase_main<- read_sas("JSSAMsubmission_mainStage_R1_eligibleMain.sas7bdat")

#main dataset
setwd("O:/AFHS-DATA/Analysis/Shiyu/dissertation/JSSAM code data submission")
dMainFw<- read_sas("JSSAMsubmission_mainStage_R1_male.sas7bdat")
dMainMw<- read_sas("JSSAMsubmission_mainStage_R1_female.sas7bdat")




# Response rate ----
# Who was selected? Informant or "another member"?
table(dCase_main$ExportBlock_InfIsSelected, exclude= F)

# response rate
table(dCase_main$ExportBlock_InfIsSelected, dCase_main$mainResp, exclude= F)




# Main survey estimates ----
## Male ----
dMainMw$SecMaleA_EVRCOHAB_original<- dMainMw$SecMaleA_EVRCOHAB
dMainMw<- dMainMw%>% mutate(
  EVRCOHAB_sz= case_when(
    (SecMaleA_MARSTAT== 2 | SecMaleA_EVCOHAB1== 1 | SecMaleA_EVCOHAB2 ==1) ~ 1,
    TRUE~ 0
  ),
  SecMaleA_EVRCOHAB= EVRCOHAB_sz
)
table(dMainMw$SecMaleA_EVRCOHAB_original, dMainMw$SecMaleA_EVRCOHAB, exclude= F)


varM<- c("SecMaleA_EVRCOHAB",
         "SecMaleA_ONOWN",
         "SecMaleA_GOSCHOL",
         "SecMaleA_PARMARR",
         "SecMaleB_EVEROPER",
         "SecMaleA_WOMRASDU",
         "SecMaleA_MANRASDU")

dMainMw[varM]<- data.frame((dMainMw[varM]==1)*1) #recoding variables

options(survey.lonely.psu="adjust") #http://r-survey.r-forge.r-project.org/survey/exmample-lonely.html
design<- svrepdesign(ids= ~0, strata= ~pseudo_strata, 
                     data= dMainMw, 
                     weight= ~PS_Wgt_male1_trimmed,
                     repweights= "PS_Wgt_Male1_trimmed_BS_[1-9]", 
                     type= "bootstrap")

estimates<- data.frame(matrix(ncol = 5, nrow = 0))
for (v in varM){
  est<- svymean(~eval(parse(text= v)), design, na.rm= T)
  ci<- svyciprop(~ eval(parse(text= v)), design, na.rm= T, method= "beta")
  
  row<- c(v, mean(est), SE(est), attr(ci, "ci")[1], attr(ci, "ci")[2])
  
  estimates<- rbind(estimates, row)
}

colnames(estimates)<- c("variable", "mean", "SE", "ciLow", "ciHigh")
estimates$replicate<- "R1"
estimates

estimates_M_R1<- estimates #assigning to a different name



## Female----
varF<- c("SecFemC_EVRCOHAB",
         "SecFemA_ONOWN",
         "SecFemA_GOSCHOL",
         "SecFemB_PREGNOWQ",
         "SecFemA_PARMARR",
         "SecFemC_EVERSEX",
         "SecFemA_WOMRASDU",
         "SecFemA_MANRASDU")

dMainFw[varF]<- data.frame((dMainFw[varF]==1)*1) #recoding variables

options(survey.lonely.psu="adjust") #http://r-survey.r-forge.r-project.org/survey/exmample-lonely.html
design<- svrepdesign(ids= ~0, strata= ~pseudo_strata, 
                     data= dMainFw, 
                     weight= ~PS_Wgt_Female1_trimmed,
                     repweights= "PS_Wgt_Female1_trimmed_BS_[1-9]", 
                     type= "bootstrap")

estimates<- data.frame(matrix(ncol = 5, nrow = 0))
for (v in varF){
  est<- svymean(~eval(parse(text= v)), design, na.rm= T)
  ci<- svyciprop(~ eval(parse(text= v)), design, na.rm= T, method= "beta")
  
  row<- c(v, mean(est), SE(est), attr(ci, "ci")[1], attr(ci, "ci")[2])
  
  estimates<- rbind(estimates, row)
}

colnames(estimates)<- c("variable", "mean", "SE", "ciLow", "ciHigh")
estimates$replicate<- "R1"
estimates

estimates_F_R1<- estimates



# NSFG estimates  ==============================

setwd("O:/AFHS-DATA/Blaise_Data/Main/Analysis")
nsfgM<- read_dta("2017_2019_MaleData.dta")
dim(nsfgM)

setwd("O:/AFHS-DATA/Blaise_Data/Main/Analysis")
nsfgF<- read_dta("2017_2019_FemRespData.dta")
dim(nsfgF)

nsfg1849M<- nsfgM%>%
  filter(AGE_R>=18 & AGE_R<=49)
dim(nsfgM)
dim(nsfg1849M)

nsfg1849F<- nsfgF%>%
  filter(AGE_R>=18 & AGE_R<=49)
dim(nsfgF)
dim(nsfg1849F)

#AFHS variable names -> NSFG variable names
varM_inNSFG<- substr(varM, start= 10, stop= 1000000L)%>% tolower()
varF_inNSFG<- substr(varF, start= 9, stop= 1000000L)%>% tolower()
varM_inNSFG
varF_inNSFG


#recoding variables 
nsfg1849M[varM_inNSFG[!varM_inNSFG%in% c("womrasdu", "manrasdu")]]<- 
  nsfg1849M[varM_inNSFG[!varM_inNSFG%in% c("womrasdu", "manrasdu")]] %>% 
  dplyr::mutate_all(., funs(replace(., !(.%in% c(0, 1, 5)), NA)))

nsfg1849M<- nsfg1849M%>%
  dplyr::mutate(
    womrasdu= dplyr::case_when(
      is.na(womrasdu)~ NA_real_,
      womrasdu==1~ 1,
      womrasdu%in% c(2, 3)~ 0,
      womrasdu%in% c(8, 9)~ NA_real_
    ),
    manrasdu= dplyr::case_when(
      is.na(manrasdu)~ NA_real_,
      manrasdu==1~ 1,
      manrasdu%in% c(2, 3, 4)~ 0,
      manrasdu%in% c(8, 9)~ NA_real_
    ))

nsfg1849M[varM_inNSFG]<- data.frame((nsfg1849M[varM_inNSFG]==1)*1) 


nsfg1849F[varF_inNSFG[!varF_inNSFG%in% c("womrasdu", "manrasdu")]]<- 
  nsfg1849F[varF_inNSFG[!varF_inNSFG%in% c("womrasdu", "manrasdu")]] %>% 
  dplyr::mutate_all(., funs(replace(., !(.%in% c(0, 1, 5)), NA)))

nsfg1849F<- nsfg1849F%>%
  dplyr::mutate(
    womrasdu= dplyr::case_when(
      is.na(womrasdu)~ NA_real_,
      womrasdu==1~ 1,
      womrasdu%in% c(2, 3)~ 0,
      womrasdu%in% c(8, 9)~ NA_real_
    ),
    manrasdu= dplyr::case_when(
      is.na(manrasdu)~ NA_real_,
      manrasdu==1~ 1,
      manrasdu%in% c(2, 3, 4)~ 0,
      manrasdu%in% c(8, 9)~ NA_real_
    ))
nsfg1849F[varF_inNSFG]<- data.frame((nsfg1849F[varF_inNSFG]==1)*1)



## Male----
design<- svydesign(ids= ~secu, strata= ~sest, nest= TRUE,
                   data= nsfg1849M, 
                   weight= ~nsfg1849M$WGT2017_2019) #I turn all variable names into smallcase


estimates<- data.frame(matrix(ncol = 5, nrow = 0))
for (v in varM_inNSFG){
  est<- svymean(~eval(parse(text= v)), design, na.rm= T)
  ci<- svyciprop(~ eval(parse(text= v)), design, na.rm= T, method= "beta")
  
  row<- c(v, mean(est), SE(est), attr(ci, "ci")[1], attr(ci, "ci")[2])
  
  estimates<- rbind(estimates, row)
}

colnames(estimates)<- c("variable", "mean", "SE", "ciLow", "ciHigh")
estimates$replicate<- "NSFG"
estimates
estimates$variable<- varM

estimates_M_NSFG<- estimates

## Female----
design<- svydesign(ids= ~secu, strata= ~sest, nest= TRUE,
                   data= nsfg1849F, 
                   weight= ~nsfg1849F$WGT2017_2019) #I turn all variable names into smallcase

estimates<- data.frame(matrix(ncol = 5, nrow = 0))
for (v in varF_inNSFG){
  est<- svymean(~eval(parse(text= v)), design, na.rm= T)
  ci<- svyciprop(~ eval(parse(text= v)), design, na.rm= T, method= "beta")
  
  row<- c(v, mean(est), SE(est), attr(ci, "ci")[1], attr(ci, "ci")[2])
  
  estimates<- rbind(estimates, row)
}

colnames(estimates)<- c("variable", "mean", "SE", "ciLow", "ciHigh")
estimates$replicate<- "NSFG"
estimates
estimates$variable<- varF

estimates_F_NSFG<- estimates



# Binding estimates ----
estimates_all<- rbind(estimates_M_R1, estimates_F_R1,
                      estimates_M_R2, estimates_F_R2,
                      estimates_M_NSFG, estimates_F_NSFG)
i<- c("mean", "SE", "ciLow", "ciHigh")
estimates_all[i]<- apply(estimates_all[,i], 2, 
                         function(x) as.numeric(x)) #turn variables to numeric



## compare R1 vs. R2 ----
twoS_ttest<- function(estimate1, estimate2,
                      SE1, SE2){
  
  t_nominator<- estimate1- estimate2
  t_denominator<- sqrt(SE1^2+ SE2^2)
  t<- t_nominator/t_denominator
  t
}

for (v in c(varM, varF)){
  print(v)
  t<- twoS_ttest(estimates_all[estimates_all$variable==v & estimates_all$replicate== "R1",]$mean,
                 estimates_all[estimates_all$variable==v & estimates_all$replicate== "R2",]$mean,
                 estimates_all[estimates_all$variable==v & estimates_all$replicate== "R1",]$SE,
                 estimates_all[estimates_all$variable==v & estimates_all$replicate== "R2",]$SE
  )
  print(t)
  
}


## plotting----
estimates_all[estimates_all$replicate== "NSFG", c("variable", "mean")]

#manually ordering the variables
varorder<- c("SecMaleB_EVEROPER",
             "SecMaleA_GOSCHOL",
             "SecMaleA_ONOWN",
             "SecMaleA_EVRCOHAB",
             "SecMaleA_MANRASDU",
             "SecMaleA_WOMRASDU",
             "SecMaleA_PARMARR",
             "SecFemB_PREGNOWQ",
             "SecFemA_GOSCHOL",
             "SecFemA_ONOWN",
             "SecFemC_EVRCOHAB",
             "SecFemC_EVERSEX",
             "SecFemA_MANRASDU",
             "SecFemA_WOMRASDU",
             "SecFemA_PARMARR")
estimates_all$variable<- factor(estimates_all$variable, levels= varorder)
estimates_all<- estimates_all[order(estimates_all$variable),]

ylabel<- varDict%>%
  filter(variable%in% varorder)%>%
  mutate(variable= factor(variable, levels= varorder))%>%
  arrange(variable)%>%
  select(text)%>% pull() #sorting label
ylabel<- paste(substr(varorder, start= 4, stop= 4),
               ":", ylabel)


len<- nrow(estimates_all)/3 #adding the position on yaxis to data
yPos<- c()
yTick<- c()
for (i in 1:len){
  yPos<- c(yPos, i*6-1, i*6, i*6+1)
  yTick<- c(yTick, i*6)
}
estimates_all$yPos<- yPos 

estimates_all$replicate<- factor(estimates_all$replicate, 
                                 levels= c("NSFG", "R2", "R1"))


ggplot(data= estimates_all, aes(x= mean, y= yPos, color= replicate))+
  geom_point()+
  geom_errorbar(aes(xmin= ciLow, xmax= ciHigh, color= replicate), width=.2)+
  scale_y_continuous(breaks= yTick, labels= ylabel)+
  scale_color_manual(values= c("black","darkorange", "steelblue"))+
  theme(axis.text.y = element_text(size=9),
        panel.grid.major.x= element_blank(),
        panel.grid.minor.x= element_blank(),
        panel.grid.minor.y= element_blank())+
  labs(x = "proportion", y = "")

## comparing variance----
sampleRatio<- 22381/19381

var1<- (estimates_all[estimates_all$replicate== "R1",]$SE)^2
var2<- (estimates_all[estimates_all$replicate== "R2",]$SE)^2

var1/var2> sampleRatio
sum(var1/var2> sampleRatio)
length(var1)


# Demographic representativeness (Appendix) ====

### variable processsing ====
#main dataset
setwd("O:/AFHS-DATA/Analysis/Shiyu/dissertation/JSSAM code data submission")
datM<- read_sas("afhs_male_recoded.sas7bdat")
datM$SampleID<- as.character(datM$SampleID)

setwd("O:/AFHS-DATA/Analysis/Shiyu/dissertation/JSSAM code data submission")
datF<- read_sas("afhs_female_recoded.sas7bdat")
datF$SampleID<- as.character(datF$SampleID)


#### 1. race and ethnicity====
#Race data in the main response dataset are incomplete. Try data from screener


#does the person have multiple races?
datF$raceCount<- datF%>%
  select(SecFemA_RRACE_1, SecFemA_RRACE_2,
         SecFemA_RRACE_3, SecFemA_RRACE_4,
         SecFemA_RRACE_5)%>%
  apply(., 1, function(x) sum(!is.na(x)))


datM$raceCount<- datM%>%
  select(SecMaleA_RRACE_1, SecMaleA_RRACE_2,
         SecMaleA_RRACE_3, SecMaleA_RRACE_4,
         SecMaleA_RRACE_5)%>%
  apply(., 1, function(x) sum(!is.na(x)))


#Coding race and ethnicity into one variable `raceEthnicity`
table(datF$SecFemA_RHISP, exclude= F)
datF<- datF%>%
  dplyr::mutate(raceEthnicity= dplyr::case_when(
    SecFemA_RHISP== 1~ "Hispanic",
    raceCount==1 & SecFemA_RRACE_1== 5~ "Non-H White",
    raceCount==1 & SecFemA_RRACE_1== 4~ "Non-H Black",
    raceCount==1 & SecFemA_RRACE_1== 2~ "Non-H Other",
    raceCount==1 & SecFemA_RRACE_1== 1~ "Non-H Other",
    raceCount==1 & SecFemA_RRACE_1== 3~ "Non-H Other",
    raceCount>1 ~ "Non-H Other" #"Non-H Multi"
  ))

table(datF$raceEthnicity, exclude= F)   


datM<- datM%>%
  dplyr::mutate(raceEthnicity= dplyr::case_when(
    SecMaleA_RHISP== 1~ "Hispanic",
    raceCount==1 & SecMaleA_RRACE_1== 5~ "Non-H White",
    raceCount==1 & SecMaleA_RRACE_1== 4~ "Non-H Black",
    raceCount==1 & SecMaleA_RRACE_1== 2~ "Non-H Other",
    raceCount==1 & SecMaleA_RRACE_1== 1~ "Non-H Other",
    raceCount==1 & SecMaleA_RRACE_1== 3~ "Non-H Other",
    raceCount>1 ~ "Non-H Other" #"Non-H Multi"
  ))

table(datM$raceEthnicity, exclude= F)   


order<- c("Non-H White", "Non-H Black", "Non-H Other", "Hispanic")

datF$raceEthnicity<- factor(datF$raceEthnicity, levels= order)
datM$raceEthnicity<- factor(datM$raceEthnicity, levels= order)


#### 2. Education====
table(datF$SecFemA_HIGRADE, exclude= F)

datF<- datF%>%
  dplyr::mutate(educ= dplyr::case_when(
    SecFemA_HIGRADE<=12 ~ "high school or less",
    SecFemA_HIGRADE%in% c(13, 14, 15) ~ "some college",
    SecFemA_HIGRADE==16 ~ "4yearCollege",
    SecFemA_HIGRADE>=17 ~ "College+",
  ))
table(datF$educ, exclude= F)
table(datF$educ, datF$SecFemA_HIGRADE, exclude= F)

table(datM$SecMaleA_HIGRADE, exclude= F)
datM<- datM%>%
  dplyr::mutate(educ= dplyr::case_when(
    SecMaleA_HIGRADE<=12 ~ "high school or less",
    SecMaleA_HIGRADE%in% c(13, 14, 15) ~ "some college",
    SecMaleA_HIGRADE==16 ~ "4yearCollege",
    SecMaleA_HIGRADE>=17 ~ "College+",
  ))
table(datM$educ, exclude= F)
table(datM$educ, datM$SecMaleA_HIGRADE, exclude= F)

order<- c("high school or less", "some college", "4yearCollege", "College+")
datF$educ<- factor(datF$educ, levels= order)
datM$educ<- factor(datM$educ, levels= order)

#### 3. Age====
summary(datF$AGE_R)

summary(datM$AGE_R)

datF<- datF%>%
  dplyr::mutate(agecat3= dplyr::case_when(
    AGE_R<=24 ~ "18-24",
    AGE_R>24& AGE_R<=34~ "25-34",
    AGE_R>34~ "35-49"
  ))
table(datF$agecat3, exclude= F)

datM<- datM%>%
  dplyr::mutate(agecat3= dplyr::case_when(
    AGE_R<=24 ~ "18-24",
    AGE_R>24& AGE_R<=34~ "25-34",
    AGE_R>34~ "35-49"
  ))
table(datM$agecat3, exclude= F)

order<- c("18-24", "25-34", "35-49")

datF$agecat3<- factor(datF$agecat3, levels= order)
datM$agecat3<- factor(datM$agecat3, levels= order)

#### 4. Marital Status====
#SecFemA_MARSTAT1 is 8-category; SecFemA_MARSTAT is 6-category
#SecFemA_MARSTAT matches with NSFG

table(datF$SecFemA_MARSTAT, exclude= F)
table(datM$SecMaleA_MARSTAT, exclude= F)

order<- c("married", "with partner", "widowed", 
          "divorced", "separated", "never married")

datF$SecFemA_MARSTAT<- factor(datF$SecFemA_MARSTAT,
                              levels= c(1, 2, 3, 4, 5, 6),
                              labels = order)
datM$SecMaleA_MARSTAT<- factor(datM$SecMaleA_MARSTAT, 
                               levels= c(1, 2, 3, 4, 5, 6),
                               labels= order)

datF<- datF%>% mutate(
  marstat3= case_when(
    SecFemA_MARSTAT%in% c("widowed", "divorced", "separated")~ "w/d/s",
    TRUE~ as.character(SecFemA_MARSTAT)
  )
)
table(datF$marstat3, exclude= F)

datM<- datM%>% mutate(
  marstat3= case_when(
    SecMaleA_MARSTAT%in% c("widowed", "divorced", "separated")~ "w/d/s",
    TRUE~ as.character(SecMaleA_MARSTAT)
  )
)
table(datM$marstat3, exclude= F)




### Replicate 1====

#Reading R1 weights
# base weights
setwd("O:/AFHS-DATA/Analysis/Shiyu/dissertation/JSSAM code data submission")
rep1<- read.csv("JSSAMsubmission_R1_baseWeight.csv")

datM1<- datM%>% 
  filter(replicate==1)%>%
  left_join(rep1%>% 
              mutate(SampleLineId= as.character(SampleLineId))%>%
              select(contains("RespBaseWgt"), SampleLineId),
            by= c("SampleID"= "SampleLineId")
  )

datF1<- datF%>% 
  filter(replicate==1)%>%
  left_join(rep1%>% 
              mutate(SampleLineId= as.character(SampleLineId))%>%
              select(contains("RespBaseWgt"), SampleLineId),
            by= c("SampleID"= "SampleLineId")
  )



# female
options(survey.lonely.psu="adjust") #http://r-survey.r-forge.r-project.org/survey/exmample-lonely.html
designF<- svrepdesign(ids= ~0, strata= ~strata, 
                      data= datF1, 
                      weight= ~RespBaseWgt,
                      repweights= "RespBaseWgt_BS_[1-9]", 
                      type= "bootstrap")


svytable(~raceEthnicity, designF)%>% 
  prop.table()%>%
  data.frame()%>%
  write_clip()

svytable(~educ, designF)%>% 
  prop.table()%>%
  data.frame()%>%
  write_clip()

svytable(~agecat3, designF)%>% 
  prop.table()%>%
  data.frame()%>%
  write_clip()

svytable(~marstat3, designF)%>% 
  prop.table()%>%
  data.frame()%>%
  write_clip()


####male
options(survey.lonely.psu="adjust") #http://r-survey.r-forge.r-project.org/survey/exmample-lonely.html
designM<- svrepdesign(ids= ~0, strata= ~strata, 
                      data= datM1, 
                      weight= ~RespBaseWgt,
                      repweights= "RespBaseWgt_BS_[1-9]", 
                      type= "bootstrap")


svytable(~raceEthnicity, designM)%>% 
  prop.table()%>%
  data.frame()%>%
  write_clip()

svytable(~educ, designM)%>% 
  prop.table()%>%
  data.frame()%>%
  write_clip()

svytable(~agecat3, designM)%>% 
  prop.table()%>%
  data.frame()%>%
  write_clip()


svytable(~marstat3, designM)%>% 
  prop.table()%>%
  data.frame()%>%
  write_clip()






### Replicate 2====

#Reading R2 weights (I created based on Raphael's code)
# base weights
setwd("O:/AFHS-DATA/Analysis/Shiyu/dissertation/JSSAM code data submission")
rep2<- read.csv("JSSAMsubmission_R2_baseWeight.csv")



datF2<- datF%>% 
  filter(replicate==2)%>%
  left_join(rep2%>% 
              mutate(SampleLineId= as.character(SampleLineId))%>%
              select(contains("RespBaseWgt"), SampleLineId),
            by= c("SampleID"= "SampleLineId")
  )

datM2<- datM%>% 
  filter(replicate==2)%>%
  left_join(rep2%>% 
              mutate(SampleLineId= as.character(SampleLineId))%>%
              select(contains("RespBaseWgt"), SampleLineId),
            by= c("SampleID"= "SampleLineId")
  )



# female
options(survey.lonely.psu="adjust") #http://r-survey.r-forge.r-project.org/survey/exmample-lonely.html
designF<- svrepdesign(ids= ~0, strata= ~strata, 
                      data= datF2, 
                      weight= ~RespBaseWgt,
                      repweights= "RespBaseWgt_BS_[1-9]", 
                      type= "bootstrap")


svytable(~raceEthnicity, designF)%>% 
  prop.table()%>%
  data.frame()%>%
  write_clip()

svytable(~educ, designF)%>% 
  prop.table()%>%
  data.frame()%>%
  write_clip()

svytable(~agecat3, designF)%>% 
  prop.table()%>%
  data.frame()%>%
  write_clip()

svytable(~marstat3, designF)%>% 
  prop.table()%>%
  data.frame()%>%
  write_clip()


####male
options(survey.lonely.psu="adjust") #http://r-survey.r-forge.r-project.org/survey/exmample-lonely.html
designM<- svrepdesign(ids= ~0, strata= ~strata, 
                      data= datM2, 
                      weight= ~RespBaseWgt,
                      repweights= "RespBaseWgt_BS_[1-9]", 
                      type= "bootstrap")


svytable(~raceEthnicity, designM)%>% 
  prop.table()%>%
  data.frame()%>%
  write_clip()

svytable(~educ, designM)%>% 
  prop.table()%>%
  data.frame()%>%
  write_clip()

svytable(~agecat3, designM)%>% 
  prop.table()%>%
  data.frame()%>%
  write_clip()


svytable(~marstat3, designM)%>% 
  prop.table()%>%
  data.frame()%>%
  write_clip()


### NSFG demographics ----

#Subset the dataset by age
nsfg1849F<- nsfgF%>%
  filter(AGE_R>=18 & AGE_R<=49)
dim(nsfgF)
dim(nsfg1849F)

nsfg1849M<- nsfgM%>%
  filter(AGE_R>=18 & AGE_R<=49)
dim(nsfgM)
dim(nsfg1849M)


## 1. Race and ethnicity ====
table(nsfg1849F$HISPRACE2, exclude= F)
table(nsfg1849M$HISPRACE2, exclude= F)

order<- c("Hispanic", "Non-H White", "Non-H Black", "Non-H Other")

nsfg1849F$HISPRACE2<- factor(nsfg1849F$HISPRACE2, 
                             levels= c(1, 2, 3, 4), 
                             labels= order)

nsfg1849M$HISPRACE2<- factor(nsfg1849M$HISPRACE2, 
                             levels= c(1, 2, 3, 4), 
                             labels= order)


## 2. Education ====
table(nsfg1849F$higrade, exclude= F)
nsfg1849F<- nsfg1849F%>%
  dplyr::mutate(educ= dplyr::case_when(
    higrade<=12 ~ "high school or less",
    higrade%in% c(13, 14, 15) ~ "some college",
    higrade==16 ~ "4yearCollege",
    higrade>=17 ~ "College+",
  ))
table(nsfg1849F$educ, exclude= F)
table(nsfg1849F$educ, nsfg1849F$higrade, exclude= F)

table(nsfg1849M$higrade, exclude= F)
nsfg1849M<- nsfg1849M%>%
  dplyr::mutate(educ= dplyr::case_when(
    higrade<=12 ~ "high school or less",
    higrade%in% c(13, 14, 15) ~ "some college",
    higrade==16 ~ "4yearCollege",
    higrade>=17 & higrade<=19 ~ "College+",
    higrade%in% c(98, 99)~ NA_character_
  ))
table(nsfg1849M$educ, exclude= F)
table(nsfg1849M$educ, nsfg1849M$higrade, exclude= F)

order<- c("high school or less", "some college", "4yearCollege", "College+")
nsfg1849F$educ<- factor(nsfg1849F$educ, levels= order)
nsfg1849M$educ<- factor(nsfg1849M$educ, levels= order)


## 3. Age ====
summary(nsfg1849F$AGE_R, exclude= F)
mean(nsfg1849F$AGE_R)
sd(nsfg1849F$AGE_R)

summary(nsfg1849M$AGE_R, exclude= F)
mean(nsfg1849M$AGE_R)
sd(nsfg1849M$AGE_R)


nsfg1849F<- nsfg1849F%>%
  dplyr::mutate(agecat3= dplyr::case_when(
    AGE_R<=24 ~ "18-24",
    AGE_R>24& AGE_R<=34~ "25-34",
    AGE_R>34~ "35-49"
  ))
table(nsfg1849F$agecat3, exclude= F)

nsfg1849M<- nsfg1849M%>%
  dplyr::mutate(agecat3= dplyr::case_when(
    AGE_R<=24 ~ "18-24",
    AGE_R>24& AGE_R<=34~ "25-34",
    AGE_R>34~ "35-49"
  ))
table(nsfg1849M$agecat3, exclude= F)

order<- c("18-24", "25-34", "35-49")

nsfg1849F$agecat3<- factor(nsfg1849F$agecat3, levels= order)
nsfg1849M$agecat3<- factor(nsfg1849M$agecat3, levels= order)


## 4. Marital status ====
order<- c("married", "with partner", "widowed", 
          "divorced", "separated", "never married")

table(nsfg1849F$marstat)
nsfg1849F<- nsfg1849F%>%
  dplyr::mutate(
    marital= dplyr::case_when(
      marstat%in% c(8, 9) ~ NA_real_,
      TRUE~ as.numeric(marstat)),
    
    marital= factor(marital, 
                    levels= c(1, 2, 3, 4, 5, 6),
                    labels= order),
    
    marstat3= case_when(
      marital%in% c("widowed", "divorced", "separated")~ "w/d/s",
      TRUE~ as.character(marital))
  )
table(nsfg1849F$marstat, nsfg1849F$marstat3, exclude= F)


table(nsfg1849M$marstat)
nsfg1849M<- nsfg1849M%>%
  dplyr::mutate(
    marital= dplyr::case_when(
      marstat%in% c(8, 9) ~ NA_real_,
      TRUE~ as.numeric(marstat)),
    
    marital= factor(marital, 
                    levels= c(1, 2, 3, 4, 5, 6),
                    labels= order),
    
    marstat3= case_when(
      marital%in% c("widowed", "divorced", "separated")~ "w/d/s",
      TRUE~ as.character(marital))
  )


table(nsfg1849M$marstat, nsfg1849M$marstat3, exclude= F)



### Chi: R1 vs. R2 ----
AFHS_F<- rbind(datF1, datF2)
AFHS_M<- rbind(datM1, datM2)

designF<- svrepdesign(ids= ~0, strata= ~strata, 
                      data= AFHS_F, 
                      weight= ~RespBaseWgt,
                      repweights= "RespBaseWgt_BS_[1-9]", 
                      type= "bootstrap")

designM<- svrepdesign(ids= ~0, strata= ~strata, 
                      data= AFHS_M, 
                      weight= ~RespBaseWgt,
                      repweights= "RespBaseWgt_BS_[1-9]", 
                      type= "bootstrap")

t1<- svytable(~raceEthnicity+replicate, designF)
summary(t1, statistic="Chisq")

t1<- svytable(~educ+replicate, designF)
summary(t1, statistic="Chisq")

t1<- svytable(~agecat3+replicate, designF)
summary(t1, statistic="Chisq")

t1<- svytable(~marstat3+replicate, designF)
summary(t1, statistic="Chisq")



t1<- svytable(~raceEthnicity+replicate, designM)
summary(t1, statistic="Chisq")

t1<- svytable(~educ+replicate, designM)
summary(t1, statistic="Chisq")

t1<- svytable(~agecat3+replicate, designM)
summary(t1, statistic="Chisq")

t1<- svytable(~marstat3+replicate, designM)
summary(t1, statistic="Chisq")

### Chi: R1 vs. NSFG ----

# female
datF1$w<- datF1$RespBaseWgt
t<- datF1[c("raceEthnicity", "educ", "agecat3", "marstat3", 
            "w")]
t$afhs<- 1


nsfg1849F$w<- nsfg1849F$WGT2017_2019
b<- nsfg1849F[c("HISPRACE2", "educ", "agecat3", "marstat3", 
                "w")]
b$afhs<- 0

names(t)<- c("raceEthnicity", "educ", "agecat3", "marstat3", "w", "afhs")
names(b)<- c("raceEthnicity", "educ", "agecat3", "marstat3", "w", "afhs")

comF<- rbind(t, b)

designF<- svydesign(ids= ~0, strata= NULL,
                    data= comF, 
                    weight= ~w)



t1<- svytable(~raceEthnicity+afhs, designF)
summary(t1, statistic="Chisq")

t1<- svytable(~educ+afhs, designF)
summary(t1, statistic="Chisq")

t1<- svytable(~agecat3+afhs, designF)
summary(t1, statistic="Chisq")

t1<- svytable(~marstat3+afhs, designF)
summary(t1, statistic="Chisq")


# male

datM1$w<- datM1$RespBaseWgt
t<- datM1[c("raceEthnicity", "educ", "agecat3", "marstat3", 
            "w")]
t$afhs<- 1


nsfg1849M$w<- nsfg1849M$WGT2017_2019
b<- nsfg1849M[c("HISPRACE2", "educ", "agecat3", "marstat3", 
                "w")]
b$afhs<- 0

names(t)<- c("raceEthnicity", "educ", "agecat3", "marstat3", "w", "afhs")
names(b)<- c("raceEthnicity", "educ", "agecat3", "marstat3", "w", "afhs")

comM<- rbind(t, b)

designM<- svydesign(ids= ~0, strata= NULL,
                    data= comM, 
                    weight= ~w)



t1<- svytable(~raceEthnicity+afhs, designM)
summary(t1, statistic="Chisq")

t1<- svytable(~educ+afhs, designM)
summary(t1, statistic="Chisq")

t1<- svytable(~agecat3+afhs, designM)
summary(t1, statistic="Chisq")

t1<- svytable(~marstat3+afhs, designM)
summary(t1, statistic="Chisq")



### Chi: R2 vs. NSFG ----

# female
datF2$w<- datF2$RespBaseWgt
t<- datF2[c("raceEthnicity", "educ", "agecat3", "marstat3", 
            "w")]
t$afhs<- 1


nsfg1849F$w<- nsfg1849F$WGT2017_2019
b<- nsfg1849F[c("HISPRACE2", "educ", "agecat3", "marstat3", 
                "w")]
b$afhs<- 0

names(t)<- c("raceEthnicity", "educ", "agecat3", "marstat3", "w", "afhs")
names(b)<- c("raceEthnicity", "educ", "agecat3", "marstat3", "w", "afhs")

comF<- rbind(t, b)

designF<- svydesign(ids= ~0, strata= NULL,
                    data= comF, 
                    weight= ~w)



t1<- svytable(~raceEthnicity+afhs, designF)
summary(t1, statistic="Chisq")

t1<- svytable(~educ+afhs, designF)
summary(t1, statistic="Chisq")

t1<- svytable(~agecat3+afhs, designF)
summary(t1, statistic="Chisq")

t1<- svytable(~marstat3+afhs, designF)
summary(t1, statistic="Chisq")


# male

datM2$w<- datM2$RespBaseWgt
t<- datM2[c("raceEthnicity", "educ", "agecat3", "marstat3", 
            "w")]
t$afhs<- 1


nsfg1849M$w<- nsfg1849M$WGT2017_2019
b<- nsfg1849M[c("HISPRACE2", "educ", "agecat3", "marstat3", 
                "w")]
b$afhs<- 0

names(t)<- c("raceEthnicity", "educ", "agecat3", "marstat3", "w", "afhs")
names(b)<- c("raceEthnicity", "educ", "agecat3", "marstat3", "w", "afhs")

comM<- rbind(t, b)

designM<- svydesign(ids= ~0, strata= NULL,
                    data= comM, 
                    weight= ~w)



t1<- svytable(~raceEthnicity+afhs, designM)
summary(t1, statistic="Chisq")

t1<- svytable(~educ+afhs, designM)
summary(t1, statistic="Chisq")

t1<- svytable(~agecat3+afhs, designM)
summary(t1, statistic="Chisq")

t1<- svytable(~marstat3+afhs, designM)
summary(t1, statistic="Chisq")



