1. The American Family Health Study (AFHS) acknowledges support from the Eunice Kennedy Shriver National Institute of Child Health & Human Development (NICHD) for grant R01HD095920 and NICHD for center grant P2CHD041028 to the University of Michigan Population Studies Center. 

2. More information about the AFHS can be found at https://afhs.isr.umich.edu/

3. This folder contains data of the National Survey of Family Growth that were downloaded from https://www.cdc.gov/nchs/nsfg/index.htm

